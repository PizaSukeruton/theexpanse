import pkg from 'pg';
const { Pool } = pkg;

import TeacherComponent from './TeacherComponent.js';
import StudentComponent from './StudentComponent.js';
import EvaluationComponent from './EvaluationComponent.js';
import BeltProgressionManager from './BeltProgressionManager.js';
import PerformanceMonitor from './PerformanceMonitor.js';
import { scoreStoryVsSequenceAttempt } from '../StorySenseEngine.mjs';

class TSELoopManager {
    constructor(pool) {
        if (!pool) {
            throw new Error("Database pool is required for TSELoopManager");
        }
        this.pool = pool;
        this.teacherComponent = new TeacherComponent(pool);
        this.studentComponent = new StudentComponent(pool);
        this.evaluationComponent = new EvaluationComponent(pool);
        this.beltProgressionManager = new BeltProgressionManager(pool);
        this.performanceMonitor = new PerformanceMonitor(pool);
        this.hexCounter = null;
    }

    async initialize() {
        await this.teacherComponent.initialize();
        await this.studentComponent.initialize();
        await this.initializeHexCounter();
        console.log("TSELoopManager initialized. Next cycle ID hex:", this.hexCounter.toString(16).toUpperCase());
    }

    async initializeHexCounter() {
        const result = await this.pool.query(`
            SELECT cycleid
            FROM tsecycles
            WHERE cycleid >= '#800000' AND cycleid <= '#80FFFF'
            ORDER BY cycleid DESC
            LIMIT 1
        `);

        if (result.rows.length > 0) {
            this.hexCounter = parseInt(result.rows[0].cycleid.substring(1), 16) + 1;
        } else {
            this.hexCounter = 0x800000;
        }
    }

    generateCycleId() {
        const hexId = this.hexCounter.toString(16).toUpperCase().padStart(6, '0');
        this.hexCounter++;
        return `#${hexId}`;
    }

    async startKnowledgeCycle({ characterId, query = null, domain = null }) {
        if (domain === 'story_sense') {
            const cycle_id = this.generateCycleId();
            const client = await this.pool.connect();

            try {
                await client.query('BEGIN');

                const cycleMetadata = {
                    module: 'story_sense',
                    characterId: characterId,
                    domain: 'story_sense',
                    startTime: new Date().toISOString()
                };

                const cycleQuery = `
                    INSERT INTO tsecycles (
                        cycleid, cycletype, status, metadata
                    ) VALUES ($1, $2, $3, $4)
                `;

                await client.query(cycleQuery, [
                    cycle_id,
                    'story_sense',
                    'in_progress',
                    cycleMetadata
                ]);

                console.log(`[TSE-STORY] Knowledge cycle started: ${cycle_id} for ${characterId}`);

                const teacherData = await this.teacherComponent.handleKnowledgeCycle(cycle_id, characterId, query, domain, client);
                const studentData = await this.studentComponent.handleKnowledgeCycle(
                    cycle_id,
                    characterId,
                    teacherData.algorithm_decision.taskTypeId,
                    teacherData.record_id,
                    client
                );

                const evaluationResult = await this.evaluationComponent.performAnalysis(
                    cycle_id,
                    teacherData.record_id,
                    studentData.record_id,
                    1
                );

                console.log('[TSE-Eval] Evaluation complete:', evaluationResult.record_id, 'Score:', evaluationResult.score);

                const beltUpdate = await this.beltProgressionManager.updateProgressionFromEvaluation(
                    characterId,
                    evaluationResult
                );

                console.log('[TSE-Belt] Progression updated:', beltUpdate);

                await client.query('COMMIT');

                return {
                    cycle: { cycle_id, domain },
                    teacher: teacherData,
                    student: studentData,
                    evaluation: {
                        record_id: evaluationResult.record_id,
                        effectiveness_score: evaluationResult.effectiveness_score,
                        efficiency_score: evaluationResult.efficiency_score,
                        innovation_score: evaluationResult.innovation_score,
                        cultural_score: evaluationResult.cultural_score,
                        weighted_score: evaluationResult.score
                    },
                    belt_progression: beltUpdate
                };
            } catch (error) {
                await client.query('ROLLBACK');
                console.error(`[TSE] Failed knowledge cycle ${cycle_id}:`, error);
                throw error;
            } finally {
                client.release();
            }
        }
    }
}

export default TSELoopManager;
