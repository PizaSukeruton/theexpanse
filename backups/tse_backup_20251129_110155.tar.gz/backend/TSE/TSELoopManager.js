import pkg from 'pg';
const { Pool } = pkg;

import TeacherComponent from './TeacherComponent.js';
import StudentComponent from './StudentComponent.js';
import EvaluationComponent from './EvaluationComponent.js';
import PerformanceMonitor from './PerformanceMonitor.js';
import { scoreStoryVsSequenceAttempt } from '../StorySenseEngine.mjs';

class TSELoopManager {
    constructor(pool) {
        if (!pool) {
            throw new Error("Database pool is required for TSELoopManager");
        }
        this.pool = pool;
        this.teacherComponent = new TeacherComponent(pool);
        this.studentComponent = new StudentComponent(pool);
        this.evaluationComponent = new EvaluationComponent(pool);
        this.performanceMonitor = new PerformanceMonitor(pool);
        this.hexCounter = null;
    }

    async initialize() {
        await this.teacherComponent.initialize();
        await this.studentComponent.initialize();
        await this.initializeHexCounter();
        console.log("TSELoopManager initialized. Next cycle ID hex:", this.hexCounter.toString(16).toUpperCase());
    }

    async initializeHexCounter() {
        const result = await this.pool.query(`
            SELECT cycleid
            FROM tsecycles
            WHERE cycleid >= '#800000' AND cycleid <= '#80FFFF'
            ORDER BY cycleid DESC
            LIMIT 1
        `);

        if (result.rows.length > 0) {
            this.hexCounter = parseInt(result.rows[0].cycleid.substring(1), 16) + 1;
        } else {
            this.hexCounter = 0x800000;
        }
    }

    generateCycleId() {
        const hexId = this.hexCounter.toString(16).toUpperCase().padStart(6, '0');
        this.hexCounter++;
        return `#${hexId}`;
    }

    async startKnowledgeCycle({ characterId, query = null, domain = null }) {
        if (domain === 'story_sense') {
            const cycle_id = this.generateCycleId();
            const client = await this.pool.connect();

            try {
                await client.query('BEGIN');

                const cycleMetadata = {
                    module: 'story_sense',
                    characterId: characterId,
                    domain: 'story_sense',
                    startTime: new Date().toISOString()
                };

                const cycleQuery = `
                    INSERT INTO tsecycles (
                        cycleid, cycletype, status, metadata
                    ) VALUES ($1, $2, $3, $4)
                `;

                await client.query(cycleQuery, [
                    cycle_id,
                    'story_sense',
                    'in_progress',
                    cycleMetadata
                ]);

                console.log(`[TSE-STORY] Knowledge cycle started: ${cycle_id} for ${characterId}`);

                const storyTask = await this.teacherComponent.debugStoryTaskForClaude();

                const teacherData = {
                    algorithm_decision: {
                        action: 'provide_story_sense_lesson',
                        lessonId: storyTask.current_lesson_id,
                        taskTypeId: storyTask.task_type_id,
                        taskName: storyTask.task_name,
                        characterId: characterId
                    },
                    confidence_score: 0.9,
                    predicted_outcomes: {
                        learning_impact: 'positive',
                        expected_retention: 'high'
                    },
                    instruction_data: {
                        lessonName: storyTask.lesson_name,
                        teacherDefinition: storyTask.teacher_definition,
                        teacherMicroExamples: storyTask.teacher_micro_examples,
                        teacherWorkedExample: storyTask.teacher_worked_example,
                        promptTemplate: storyTask.prompt_template,
                        expectedOutputFormat: storyTask.expected_output_format
                    },
                    character_selection_reasoning: `Story Sense lesson for ${characterId}`
                };

                const teacherRecord = await this.teacherComponent.recordChatDecision(cycle_id, teacherData);
                console.log(`[TSE-STORY] Teacher storytelling lesson recorded for cycle ${cycle_id}`);

                await scoreStoryVsSequenceAttempt(characterId);

                await client.query('COMMIT');

                return {
                    cycle: { cycle_id, domain: 'story_sense' },
                    teacherTask: teacherData,
                    storyTask
                };
            } catch (error) {
                await client.query('ROLLBACK');
                console.error(`[TSE-STORY] Failed storytelling knowledge cycle ${cycle_id}:`, error);
                throw error;
            } finally {
                client.release();
            }
        }

        const cycle_id = this.generateCycleId();
        const client = await this.pool.connect();

        try {
            await client.query('BEGIN');
            await client.query('SET CONSTRAINTS tse_student_records_cycle_id_fkey DEFERRED');

            const cycleMetadata = {
                module: 'knowledge_learning',
                characterId: characterId,
                query: query,
                domain: domain,
                startTime: new Date().toISOString()
            };

            const cycleQuery = `
                INSERT INTO tsecycles (
                    cycleid, cycletype, status, metadata
                ) VALUES ($1, $2, $3, $4)
            `;

            await client.query(cycleQuery, [
                cycle_id,
                'knowledge',
                'in_progress',
                cycleMetadata
            ]);

            const teacherData = await this.teacherComponent.handleKnowledgeCycle(cycle_id, characterId, query, domain, client);
             const studentData = await this.studentComponent.handleKnowledgeCycle(
                 cycle_id, 
                 characterId, 
                 teacherData.algorithm_decision.taskTypeId,
                 teacherData.record_id,
                 client
             );

            await client.query('COMMIT');

            return {
                cycle: { cycle_id, domain },
                teacher: teacherData,
                student: studentData
            };
        } catch (error) {
            await client.query('ROLLBACK');
            console.error(`[TSE] Failed knowledge cycle ${cycle_id}:`, error);
            throw error;
        } finally {
            client.release();
        }
    }
}

export default TSELoopManager;
