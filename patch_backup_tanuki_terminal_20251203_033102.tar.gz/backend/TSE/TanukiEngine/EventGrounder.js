import pool from "../../db/pool.js";

export default class EventGrounder {
  async ground(entity, characterId) {
    // Placeholder: current logs show all-false for "objects"; keep simple for now.
    return {
      entity,
      characterId,
      groundedEvents: {
        hasMultiverseMatch: false,
        hasOmiyageMatch: false,
        hasPsychicMatch: false,
        relatedMultiverse: [],
        relatedOmiyage: [],
        relatedPsychic: []
      }
    };
  }
}

export function generateEventStatement(eventContext) {
  const ge = eventContext && eventContext.groundedEvents;
  if (!ge) return "";

  const multi = ge.relatedMultiverse || [];
  const omiyage = ge.relatedOmiyage || [];
  const psychic = ge.relatedPsychic || [];

  if (ge.hasMultiverseMatch && multi.length) {
    const names = multi.slice(0, 1).map(e => e.event_name || "a multiverse event");
    return `I was there when ${names[0]} unfolded.`;
  }

  if (ge.hasOmiyageMatch && omiyage.length) {
    const names = omiyage.slice(0, 1).map(e => e.event_name || "an omiyage moment");
    return `An omiyage shaped me: ${names[0]}.`;
  }

  if (ge.hasPsychicMatch && psychic.length) {
    const names = psychic.slice(0, 1).map(e => e.event_name || "a psychic echo");
    return `A psychic echo still lingers from ${names[0]}.`;
  }

  return "";
}
