/**
 * commandParser.js
 * Natural Language Command Parser for CMS/EMS
 * 
 * Integrates with existing intent matcher system while adding
 * CMS-specific command patterns for entity management operations.
 */

import { socketManager } from './socketManager.js';

class CommandParser {
  constructor() {
    this.socket = socketManager;
    
    this.patterns = {
      ADD_KNOWLEDGE: /add\s+knowledge\s+["'](.+?)["']\s+to\s+(.+)/i,
      REMOVE_KNOWLEDGE: /remove\s+knowledge\s+["'](.+?)["']\s+from\s+(.+)/i,
      LIST_KNOWLEDGE: /(?:list|show)\s+knowledge(?:\s+for\s+(.+))?/i,
      LINK_RELATIONSHIP: /link\s+(.+?)\s+to\s+(.+?)\s+as\s+(.+)/i,
      SHOW_RELATIONSHIPS: /(?:show|list)\s+relationships?\s+for\s+(.+)/i,
      REMOVE_RELATIONSHIP: /remove\s+relationship\s+(\S+)/i,
      CREATE_STORY: /create\s+(?:storyline|story\s+arc)\s+["'](.+?)["']/i,
      ADD_TO_STORY: /add\s+(.+?)\s+to\s+storyline\s+["'](.+?)["']/i,
      LIST_STORYLINES: /(?:list|show)\s+storylines?(?:\s+for\s+(.+))?/i,
      SET_TRAIT: /set\s+(.+?)\s+trait\s+(.+?)\s+(\d+)/i,
      SHOW_TRAITS: /(?:show|list)\s+traits?\s+for\s+(.+)/i,
      UPLOAD_IMAGE: /upload\s+image\s+for\s+(.+)/i,
      SHOW_IMAGE: /(?:show|display)\s+image\s+(?:for|of)\s+(.+)/i,
      SHOW_ENTITY: /(?:show|display|view)\s+(.+)/i,
      LIST_ENTITIES: /list\s+(characters|knowledge|locations|events)/i,
      HELP: /^help$/i,
      CLEAR: /^clear$/i,
      SAVE: /^save$/i,
    };
    
    this.lastResolvedEntity = null;
    this.commandHistory = [];
  }

  async parse(input, context = {}) {
    const trimmedInput = input.trim();
    
    if (!trimmedInput) {
      return {
        action: 'EMPTY',
        message: 'Please enter a command.',
        timestamp: new Date().toISOString()
      };
    }
    
    this.commandHistory.push({
      input: trimmedInput,
      timestamp: new Date().toISOString()
    });
    
    if (this.commandHistory.length > 10) {
      this.commandHistory.shift();
    }
    
    if (this.patterns.HELP.test(trimmedInput)) {
      return { action: 'HELP', timestamp: new Date().toISOString() };
    }
    
    if (this.patterns.CLEAR.test(trimmedInput)) {
      return { action: 'CLEAR', timestamp: new Date().toISOString() };
    }
    
    if (this.patterns.SAVE.test(trimmedInput)) {
      return { action: 'SAVE', timestamp: new Date().toISOString() };
    }
    
    for (const [action, pattern] of Object.entries(this.patterns)) {
      const match = trimmedInput.match(pattern);
      if (match) {
        const parsedCommand = await this.handlePattern(action, match, context);
        if (parsedCommand) {
          return parsedCommand;
        }
      }
    }
    
    return this.queryIntentMatcher(trimmedInput, context);
  }

  async handlePattern(action, match, context) {
    const timestamp = new Date().toISOString();
    
    switch(action) {
      case 'ADD_KNOWLEDGE':
        return {
          action: 'ADD_KNOWLEDGE',
          knowledgeName: match[1],
          characterName: match[2],
          requiresResolution: true,
          rawInput: match[0],
          timestamp
        };
      
      case 'REMOVE_KNOWLEDGE':
        return {
          action: 'REMOVE_KNOWLEDGE',
          knowledgeName: match[1],
          characterName: match[2],
          requiresResolution: true,
          rawInput: match[0],
          timestamp
        };
      
      case 'LIST_KNOWLEDGE':
        const characterName = match[1] || null;
        return {
          action: 'LIST_KNOWLEDGE',
          characterName,
          requiresResolution: characterName ? true : false,
          rawInput: match[0],
          timestamp
        };
      
      case 'LINK_RELATIONSHIP':
        return {
          action: 'LINK_RELATIONSHIP',
          sourceEntity: match[1],
          targetEntity: match[2],
          relationshipType: match[3],
          requiresResolution: true,
          rawInput: match[0],
          timestamp
        };
      
      case 'SHOW_RELATIONSHIPS':
        return {
          action: 'SHOW_RELATIONSHIPS',
          entityName: match[1],
          requiresResolution: true,
          rawInput: match[0],
          timestamp
        };
      
      case 'REMOVE_RELATIONSHIP':
        return {
          action: 'REMOVE_RELATIONSHIP',
          relationshipId: match[1],
          requiresResolution: false,
          rawInput: match[0],
          timestamp
        };
      
      case 'CREATE_STORY':
        return {
          action: 'CREATE_STORY',
          storyTitle: match[1],
          requiresResolution: false,
          rawInput: match[0],
          timestamp
        };
      
      case 'ADD_TO_STORY':
        return {
          action: 'ADD_TO_STORY',
          characterName: match[1],
          storyTitle: match[2],
          requiresResolution: true,
          rawInput: match[0],
          timestamp
        };
      
      case 'LIST_STORYLINES':
        const forCharacter = match[1] || null;
        return {
          action: 'LIST_STORYLINES',
          characterName: forCharacter,
          requiresResolution: forCharacter ? true : false,
          rawInput: match[0],
          timestamp
        };
      
      case 'SET_TRAIT':
        return {
          action: 'SET_TRAIT',
          characterName: match[1],
          traitName: match[2],
          traitValue: parseInt(match[3]),
          requiresResolution: true,
          rawInput: match[0],
          timestamp
        };
      
      case 'SHOW_TRAITS':
        return {
          action: 'SHOW_TRAITS',
          characterName: match[1],
          requiresResolution: true,
          rawInput: match[0],
          timestamp
        };
      
      case 'UPLOAD_IMAGE':
        return {
          action: 'UPLOAD_IMAGE',
          entityName: match[1],
          requiresResolution: true,
          rawInput: match[0],
          timestamp
        };
      
      case 'SHOW_IMAGE':
        return {
          action: 'SHOW_IMAGE',
          entityName: match[1],
          requiresResolution: true,
          rawInput: match[0],
          timestamp
        };
      
      case 'SHOW_ENTITY':
        return {
          action: 'SHOW_ENTITY',
          entityName: match[1],
          requiresResolution: true,
          rawInput: match[0],
          timestamp
        };
      
      case 'LIST_ENTITIES':
        return {
          action: 'LIST_ENTITIES',
          entityType: match[1].toLowerCase(),
          requiresResolution: false,
          rawInput: match[0],
          timestamp
        };
      
      default:
        return null;
    }
  }

  async queryIntentMatcher(query, context) {
    try {
      console.log('[CommandParser] Querying intent matcher:', query);
      
      const response = await this.socket.sendCommand(query, {
        domain: 'character_management',
        context: context
      });
      
      console.log('[CommandParser] Intent matcher response:', response);
      
      return this.transformIntentResponse(response);
      
    } catch (error) {
      console.error('[CommandParser] Intent matcher error:', error);
      return {
        action: 'ERROR',
        message: 'Failed to process command',
        error: error.message,
        timestamp: new Date().toISOString()
      };
    }
  }

  transformIntentResponse(intentResponse) {
    const { action, entity, entityData, confidence, message } = intentResponse;
    const timestamp = new Date().toISOString();
    
    if (action === 'disambiguate') {
      return {
        action: 'DISAMBIGUATE',
        options: intentResponse.options,
        message: message,
        originalQuery: intentResponse.query,
        timestamp
      };
    }
    
    if (action === 'confirm') {
      return {
        action: 'CONFIRM',
        entity: entity,
        entityData: entityData,
        confidence: confidence,
        message: message,
        timestamp
      };
    }
    
    if (action === 'clarify') {
      return {
        action: 'CLARIFY',
        message: message,
        originalQuery: intentResponse.query,
        timestamp
      };
    }
    
    if (action === 'not_found') {
      return {
        action: 'NOT_FOUND',
        message: message || `Could not find entity: ${intentResponse.query}`,
        query: intentResponse.query,
        timestamp
      };
    }
    
    if (action === 'single_match' && entityData) {
      this.lastResolvedEntity = entityData;
      
      return {
        action: 'DISPLAY_ENTITY',
        entity: entityData,
        confidence: confidence,
        message: message,
        type: intentResponse.type,
        timestamp
      };
    }
    
    return {
      action: 'UNKNOWN',
      message: 'Could not understand command',
      originalInput: intentResponse.query,
      timestamp
    };
  }

  async resolveEntity(entityName, context) {
    const result = await this.queryIntentMatcher(entityName, context);
    
    if (result.action === 'DISPLAY_ENTITY' && result.entity) {
      return {
        success: true,
        entity: result.entity,
        confidence: result.confidence
      };
    }
    
    if (result.action === 'DISAMBIGUATE') {
      return {
        success: false,
        needsDisambiguation: true,
        options: result.options,
        message: result.message
      };
    }
    
    return {
      success: false,
      error: result.message || 'Entity not found',
      action: result.action
    };
  }

  getHelpText() {
    return `
**Entity Management System - Commands**

**Character Display:**
  show [character name]     - Display character profile
  list characters           - Show all characters

**Knowledge Management:**
  add knowledge "[topic]" to [character]      - Add knowledge tag
  remove knowledge "[topic]" from [character] - Remove knowledge tag
  list knowledge for [character]              - Show character's knowledge

**Relationship Management:**
  link [char1] to [char2] as [type]  - Create relationship
  show relationships for [character] - Display relationships
  remove relationship [id]           - Delete relationship

**Story Arc Management:**
  create storyline "[title]"              - Create new story arc
  add [character] to storyline "[title]"  - Add character to arc
  list storylines                         - Show all story arcs
  list storylines for [character]         - Character's arcs

**Trait Management:**
  set [character] trait [name] [value]  - Set trait value (0-100)
  show traits for [character]           - Display character traits

**System Commands:**
  help   - Show this help text
  clear  - Clear display
  save   - Save changes

**Natural Language:**
You can also use natural language queries like:
  "Who is Piza Sukeruton?"
  "Tell me about Claude"
  "What is The Cheese Wars?"
    `.trim();
  }

  getHistory() {
    return this.commandHistory;
  }

  getLastEntity() {
    return this.lastResolvedEntity;
  }
}

export const commandParser = new CommandParser();
export default commandParser;
