// ============================================================================
// Entity Management Module (Clean Rebuilt Version)
// ============================================================================

const EntityManager = {
    apiBase: '/api/admin',

    // ------------------------------------------------------------------------
    // Initialize
    // ------------------------------------------------------------------------
    init() {
        console.log('Entity Manager initialized');
    },

    // ------------------------------------------------------------------------
    // Fetch & list all knowledge entities
    // ------------------------------------------------------------------------
    async showAllEntities() {
        try {
            const response = await fetch(`${this.apiBase}/knowledge-entities`, {
                credentials: 'include',
                headers: { "Content-Type": "application/json" }
            });

            if (!response.ok) throw new Error('Failed to fetch entities');

            const data = await response.json();
            this.displayEntityList(data.entities);

        } catch (error) {
            console.error('Error fetching entities:', error);
            this.showError('Failed to load entities');
        }
    },

    displayEntityList(entities) {
        const content = `
            <div class="entity-list-container">
                <h2 class="terminal-header">KNOWLEDGE ENTITIES</h2>

                <div class="entity-controls">
                    <button class="action-button" onclick="EntityManager.showCreateEntity()">
                        + CREATE NEW ENTITY
                    </button>
                </div>

                <table class="entity-table">
                    <thead>
                        <tr>
                            <th>HEX ID</th>
                            <th>NAME</th>
                            <th>DESCRIPTION</th>
                            <th>KNOWLEDGE COUNT</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${entities.map(entity => `
                            <tr>
                                <td class="hex-id">${entity.character_id}</td>
                                <td>${entity.character_name}</td>
                                <td class="description">${entity.description || 'No description'}</td>
                                <td class="center">${entity.knowledge_count || 0}</td>
                                <td class="actions">
                                    <button onclick="EntityManager.viewEntity('${entity.character_id}')" class="mini-button">VIEW</button>
                                    <button onclick="EntityManager.editEntity('${entity.character_id}')" class="mini-button">EDIT</button>
                                    <button onclick="EntityManager.manageRelationships('${entity.character_id}')" class="mini-button">RELATIONSHIPS</button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        document.getElementById('top-right-window-inner').innerHTML = content;
    },

    // ------------------------------------------------------------------------
    // UI helpers
    // ------------------------------------------------------------------------
    showSuccess(message) {
        const msg = document.createElement('div');
        msg.className = 'success-message';
        msg.textContent = message;
        document.body.appendChild(msg);
        setTimeout(() => msg.remove(), 3000);
    },

    showError(message) {
        const msg = document.createElement('div');
        msg.className = 'error-message';
        msg.textContent = message;
        document.body.appendChild(msg);
        setTimeout(() => msg.remove(), 5000);
    },

    // ------------------------------------------------------------------------
    // Create entity
    // ------------------------------------------------------------------------
    showCreateEntity() {
        const content = `
            <div class="create-entity-container">
                <h2 class="terminal-header">CREATE KNOWLEDGE ENTITY</h2>

                <form id="createEntityForm" class="entity-form">

                    <div class="form-group">
                        <label>ENTITY NAME:</label>
                        <input type="text" id="entityName" required class="terminal-input">
                    </div>

                    <div class="form-group">
                        <label>DESCRIPTION:</label>
                        <textarea id="entityDescription" rows="4" class="terminal-textarea"></textarea>
                    </div>

                    <div class="form-group">
                        <label>PASSWORD CONFIRMATION:</label>
                        <input type="password" id="entityPassword" required class="terminal-input">
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="action-button">CREATE ENTITY</button>
                        <button type="button" onclick="EntityManager.showAllEntities()" class="cancel-button">CANCEL</button>
                    </div>

                </form>
            </div>
        `;

        document.getElementById('top-right-window-inner').innerHTML = content;

        document.getElementById('createEntityForm')
            .addEventListener('submit', e => {
                e.preventDefault();
                this.createEntity();
            });
    },

    async createEntity() {
        const entityData = {
            entity_name: document.getElementById('entityName').value,
            description: document.getElementById('entityDescription').value,
            password: document.getElementById('entityPassword').value
        };

        try {
            const response = await fetch(`${this.apiBase}/knowledge-entity/create`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(entityData)
            });

            const data = await response.json();

            if (data.success) {
                this.showSuccess(`Entity ${data.entity.character_id} created successfully!`);
                setTimeout(() => this.showAllEntities(), 2000);
            } else {
                this.showError(data.error || 'Failed to create entity');
            }

        } catch (error) {
            console.error('Error creating entity:', error);
            this.showError('Failed to create entity');
        }
    },

    // ------------------------------------------------------------------------
    // View entity details
    // ------------------------------------------------------------------------
    async viewEntity(entityId) {
        try {
            const response = await fetch(
                `${this.apiBase}/knowledge-entity/${encodeURIComponent(entityId)}`,
                {
                    credentials: 'include',
                    headers: { "Content-Type": "application/json" }
                }
            );

            if (!response.ok) throw new Error('Failed to fetch entity');

            const data = await response.json();
            this.displayEntityDetails(data);

        } catch (error) {
            console.error('Error fetching entity:', error);
            this.showError('Failed to load entity details');
        }
    },

    displayEntityDetails(data) {
        const { entity, knowledge_items, relationships } = data;

        const content = `
            <div class="entity-details-container">
                <h2 class="terminal-header">ENTITY: ${entity.character_name}</h2>

                <div class="entity-info">
                    <div class="info-row">
                        <span class="label">HEX ID:</span>
                        <span class="value hex-id">${entity.character_id}</span>
                    </div>

                    <div class="info-row">
                        <span class="label">CATEGORY:</span>
                        <span class="value">${entity.category}</span>
                    </div>

                    <div class="info-row">
                        <span class="label">DESCRIPTION:</span>
                        <span class="value">${entity.description || 'No description'}</span>
                    </div>

                    <div class="info-row">
                        <span class="label">CREATED:</span>
                        <span class="value">${new Date(entity.created_at).toLocaleString()}</span>
                    </div>
                </div>

                <div class="section-divider"></div>

                <h3 class="section-header">KNOWLEDGE ITEMS (${knowledge_items.length})</h3>

                <div class="knowledge-items">
                    ${
                        knowledge_items.length > 0
                            ? knowledge_items.map(item => {
                                  let content = item.content;
                                  if (typeof content === 'string') {
                                      try {
                                          content = JSON.parse(content).statement || content;
                                      } catch (e) {}
                                  }
                                  return `
                                      <div class="knowledge-item">
                                          <div class="item-id">${item.knowledge_id}</div>
                                          <div class="item-content">${content}</div>
                                      </div>
                                  `;
                              }).join('')
                            : '<p class="no-data">No knowledge items found</p>'
                    }
                </div>

                <div class="section-divider"></div>

                <h3 class="section-header">RELATIONSHIPS (${relationships.length})</h3>

                <div class="relationships">
                    ${
                        relationships.length > 0
                            ? relationships.map(rel => `
                                <div class="relationship-item">
                                    <span class="rel-type">${rel.relationship_type}</span>
                                    <span class="rel-direction">
                                        ${rel.source_hex === entity.character_id ? '→' : '←'}
                                    </span>
                                    <span class="rel-entity hex-id">
                                        ${rel.source_hex === entity.character_id ? rel.target_hex : rel.source_hex}
                                    </span>
                                    <span class="rel-name">
                                        ${rel.source_hex === entity.character_id ? rel.target_name : rel.source_name}
                                    </span>
                                </div>
                              `).join('')
                            : '<p class="no-data">No relationships found</p>'
                    }
                </div>

                <div class="entity-actions">
                    <button onclick="EntityManager.editEntity('${entity.character_id}')" class="action-button">EDIT ENTITY</button>
                    <button onclick="EntityManager.manageRelationships('${entity.character_id}')" class="action-button">MANAGE RELATIONSHIPS</button>
                    <button onclick="EntityManager.showAllEntities()" class="cancel-button">BACK TO LIST</button>
                </div>
            </div>
        `;

        document.getElementById('top-right-window-inner').innerHTML = content;
    },

    // ------------------------------------------------------------------------
    // Edit entity
    // ------------------------------------------------------------------------
    editEntity(entityId) {
        fetch(`${this.apiBase}/knowledge-entity/${encodeURIComponent(entityId)}`, {
            credentials: 'include',
            headers: { "Content-Type": "application/json" }
        })
            .then(response => response.json())
            .then(data => {
                const entity = data.entity;

                const content = `
                    <div class="edit-entity-container">
                        <h2 class="terminal-header">EDIT ENTITY: ${entity.character_id}</h2>

                        <form id="editEntityForm" class="entity-form">

                            <div class="form-group">
                                <label>ENTITY NAME:</label>
                                <input type="text" id="entityName" value="${entity.character_name}" required class="terminal-input">
                            </div>

                            <div class="form-group">
                                <label>DESCRIPTION:</label>
                                <textarea id="entityDescription" rows="4" class="terminal-textarea">${entity.description || ''}</textarea>
                            </div>

                            <div class="form-actions">
                                <button type="submit" class="action-button">UPDATE ENTITY</button>
                                <button type="button" onclick="EntityManager.viewEntity('${entityId}')" class="cancel-button">CANCEL</button>
                            </div>

                        </form>
                    </div>
                `;

                document.getElementById('top-right-window-inner').innerHTML = content;

                document.getElementById('editEntityForm').addEventListener('submit', e => {
                    e.preventDefault();
                    EntityManager.updateEntity(entityId);
                });
            })
            .catch(error => {
                console.error('Error fetching entity for edit:', error);
                this.showError('Failed to load entity for editing');
            });
    },

    async updateEntity(entityId) {
        const entityData = {
            character_name: document.getElementById('entityName').value,
            description: document.getElementById('entityDescription').value
        };

        try {
            const response = await fetch(`${this.apiBase}/knowledge-entity/${encodeURIComponent(entityId)}`, {
                method: 'PUT',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(entityData)
            });

            const data = await response.json();

            if (data.success) {
                this.showSuccess('Entity updated successfully!');
                setTimeout(() => this.viewEntity(entityId), 1500);
            } else {
                this.showError(data.error || 'Failed to update entity');
            }

        } catch (error) {
            console.error('Error updating entity:', error);
            this.showError('Failed to update entity');
        }
    },

    // ------------------------------------------------------------------------
    // Relationship Manager
    // ------------------------------------------------------------------------
    async manageRelationships(entityId) {
        try {
            const [entityResp, typesResp, entitiesResp] = await Promise.all([
                fetch(`${this.apiBase}/knowledge-entity/${encodeURIComponent(entityId)}`, {
                    credentials: 'include',
                    headers: { "Content-Type": "application/json" }
                }),
                fetch(`${this.apiBase}/relationship-types`, {
                    credentials: 'include',
                    headers: { "Content-Type": "application/json" }
                }),
                fetch(`${this.apiBase}/entities?entity_type=character`, {
                    credentials: 'include',
                    headers: { "Content-Type": "application/json" }
                })
            ]);

            const entityData = await entityResp.json();
            const typesData = await typesResp.json();
            const allEntities = await entitiesResp.json();

            this.displayRelationshipManager(
                entityData.entity,
                entityData.relationships,
                typesData.types,
                allEntities
            );

        } catch (error) {
            console.error('Error loading relationship manager:', error);
            this.showError('Failed to load relationship manager');
        }
    },

    displayRelationshipManager(entity, relationships, relationshipTypes, allEntities) {
        const content = `
            <div class="relationship-manager">
                <h2 class="terminal-header">MANAGE RELATIONSHIPS: ${entity.character_name}</h2>

                <div class="create-relationship">
                    <h3>CREATE NEW RELATIONSHIP</h3>

                    <form id="createRelationshipForm" class="relationship-form">

                        <div class="form-row">
                            <select id="targetEntity" class="terminal-select" required>
                                <option value="">Select Target Entity</option>
                                ${allEntities
                                    .filter(e => e.hex_id !== entity.character_id)
                                    .map(e => `<option value="${e.hex_id}">${e.hex_id} - ${e.name}</option>`)
                                    .join('')}
                            </select>

                            <select id="relationshipType" class="terminal-select" required>
                                <option value="">Select Relationship Type</option>
                                ${relationshipTypes
                                    .map(t => `<option value="${t.type_name}">${t.type_name} - ${t.description}</option>`)
                                    .join('')}
                            </select>

                            <button type="submit" class="action-button">CREATE</button>
                        </div>

                    </form>
                </div>

                <div class="section-divider"></div>

                <h3>EXISTING RELATIONSHIPS</h3>

                <div class="relationships-list">
                    ${
                        relationships.length > 0
                            ? relationships.map(rel => `
                                <div class="relationship-row">
                                    <span class="rel-info">
                                        ${entity.character_id}
                                        <span class="rel-type">${rel.relationship_type}</span>
                                        ${rel.source_hex === entity.character_id ? rel.target_hex : rel.source_hex}
                                        (${rel.source_hex === entity.character_id ? rel.target_name : rel.source_name})
                                    </span>

                                    <button onclick="EntityManager.deleteRelationship(${rel.relationship_id}, '${entity.character_id}')" class="delete-button">
                                        DELETE
                                    </button>
                                </div>
                              `).join('')
                            : '<p class="no-data">No relationships found</p>'
                    }
                </div>

                <div class="form-actions">
                    <button onclick="EntityManager.viewEntity('${entity.character_id}')" class="cancel-button">BACK TO ENTITY</button>
                </div>
            </div>
        `;

        document.getElementById('top-right-window-inner').innerHTML = content;

        document.getElementById('createRelationshipForm').addEventListener('submit', e => {
            e.preventDefault();
            this.createRelationship(entity.character_id);
        });
    },

    async createRelationship(sourceEntityId) {
        const relationshipData = {
            source_hex: sourceEntityId,
            target_hex: document.getElementById('targetEntity').value,
            relationship_type: document.getElementById('relationshipType').value,
            metadata: {}
        };

        try {
            const response = await fetch(`${this.apiBase}/entity-relationship`, {
                method: 'POST',
                credentials: 'include',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(relationshipData)
            });

            const data = await response.json();

            if (data.success) {
                this.showSuccess('Relationship created successfully!');
                setTimeout(() => this.manageRelationships(sourceEntityId), 1000);
            } else {
                this.showError(data.error || 'Failed to create relationship');
            }

        } catch (error) {
            console.error('Error creating relationship:', error);
            this.showError('Failed to create relationship');
        }
    },

    async deleteRelationship(relationshipId, entityId) {
        if (!confirm('Are you sure you want to delete this relationship?')) return;

        try {
            const response = await fetch(`${this.apiBase}/entity-relationship/${relationshipId}`, {
                method: 'DELETE',
                credentials: 'include',
                headers: { "Content-Type": "application/json" }
            });

            const data = await response.json();

            if (data.success) {
                this.showSuccess('Relationship deleted successfully!');
                setTimeout(() => this.manageRelationships(entityId), 1000);
            } else {
                this.showError(data.error || 'Failed to delete relationship');
            }

        } catch (error) {
            console.error('Error deleting relationship:', error);
            this.showError('Failed to delete relationship');
        }
    }
};

// ============================================================================
// Expose global functions for UI buttons
// ============================================================================
window.showAllEntities = () => EntityManager.showAllEntities();
window.showCreateEntity = () => EntityManager.showCreateEntity();
window.showKnowledgeEditor = () => EntityManager.showAllEntities();
window.showEntityRelationships = () => EntityManager.showAllEntities();
window.EntityManager = EntityManager;

// ============================================================================
// Init
// ============================================================================
document.addEventListener('DOMContentLoaded', () => EntityManager.init());

// Make functions available globally for onclick handlers
window.showAllEntities = () => EntityManager.showAllEntities();
window.showCreateEntity = () => EntityManager.showCreateEntity();

// Knowledge Entity Editor placeholder (will be implemented in the next task)
window.showKnowledgeEditor = () => EntityManager.showAllEntities();

// Relationship selector (placeholder, next task)
window.showEntityRelationships = () => EntityManager.showAllEntities();

// Make EntityManager globally accessible
window.EntityManager = EntityManager;

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    EntityManager.init();
});

// ------------------------------
// ENTITY SELECTOR: KNOWLEDGE EDITOR
// ------------------------------
EntityManager.showKnowledgeEditor = function () {
    fetch(`${this.apiBase}/knowledge-entities`, {
        credentials: 'include',
        headers: { "Content-Type": "application/json" }
    })
    .then(res => res.json())
    .then(data => {
        const content = `
            <div class="entity-list-container">
                <h2 class="terminal-header">KNOWLEDGE ENTITY EDITOR</h2>
                <p>Select an entity to edit:</p>
                <table class="entity-table">
                    <thead>
                        <tr>
                            <th>HEX</th><th>NAME</th><th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${data.entities.map(e => `
                            <tr>
                                <td>${e.character_id}</td>
                                <td>${e.character_name}</td>
                                <td>
                                    <button class="mini-button"
                                        onclick="EntityManager.editEntity('${e.character_id}')">
                                        EDIT
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                <button onclick="EntityManager.showAllEntities()" class="cancel-button">BACK</button>
            </div>`;
        document.getElementById('top-right-window-inner').innerHTML = content;
    });
};


// ------------------------------
// ENTITY SELECTOR: RELATIONSHIP MANAGER
// ------------------------------
EntityManager.showRelationshipSelector = function () {
    fetch(`${this.apiBase}/knowledge-entities`, {
        credentials: 'include',
        headers: { "Content-Type": "application/json" }
    })
    .then(res => res.json())
    .then(data => {
        const content = `
            <div class="entity-list-container">
                <h2 class="terminal-header">ENTITY RELATIONSHIPS</h2>
                <p>Select an entity to manage relationships:</p>
                <table class="entity-table">
                    <thead>
                        <tr>
                            <th>HEX</th><th>NAME</th><th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${data.entities.map(e => `
                            <tr>
                                <td>${e.character_id}</td>
                                <td>${e.character_name}</td>
                                <td>
                                    <button class="mini-button"
                                        onclick="EntityManager.manageRelationships('${e.character_id}')">
                                        RELATIONSHIPS
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                <button onclick="EntityManager.showAllEntities()" class="cancel-button">BACK</button>
            </div>`;
        document.getElementById('top-right-window-inner').innerHTML = content;
    });
};

