import express from 'express';
const router = express.Router();

import pool from '../db/pool.js';
import TSELoopManager from './TSELoopManager.js';
import BeltProgressionManager from './BeltProgressionManager.js';
import PerformanceMonitor from './PerformanceMonitor.js';
import KnowledgeResponseEngine from './helpers/KnowledgeResponseEngine.js';

const knowledgeEngine = new KnowledgeResponseEngine(pool);
await knowledgeEngine.initialize();

const tseManager = new TSELoopManager(pool);
await tseManager.initialize();

router.get('/', (req, res) => {
  res.json({ 
    message: 'TSE Pipeline API',
    endpoints: [
      '/status',
      '/exam/:characterId',
      '/progress/:characterId',
      '/belt/:characterId',
      '/performance/:characterId',
      '/knowledge/response',
      '/knowledge/profile/:characterId',
      '/cycle/knowledge'
    ]
  });
});

router.get('/status', async (req, res) => {
  try {
    res.json({ 
      status: 'TSE Pipeline operational',
      components: {
        loopManager: 'TSELoopManager active',
        beltProgression: 'BeltProgressionManager ready',
        performance: 'PerformanceMonitor online',
        knowledgeEngine: 'KnowledgeResponseEngine ready'
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/cycle/knowledge', async (req, res) => {
  try {
    const { characterId, query, domain } = req.body;
    
    if (!characterId || !query) {
      return res.status(400).json({ 
        error: 'Missing required fields: characterId and query' 
      });
    }
    
    console.log(`[TSE API] Starting knowledge cycle for ${characterId}: "${query}"`);
    
    const result = await tseManager.startKnowledgeCycle({
      characterId,
      query,
      domain: domain || 'general'
    });
    
    res.json({
      success: true,
      cycleId: result.cycle.cycle_id,
      score: result.overallScore,
      deliveryStyle: result.deliveryStyle,
      response: result.response,
      learningProfile: result.learningProfile,
      evaluation: result.evaluation
    });
    
  } catch (error) {
    console.error('[TSE API] Knowledge cycle error:', error);
    res.status(500).json({ 
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

router.post('/knowledge/response', async (req, res) => {
  try {
    const { characterId, query, context } = req.body;
    
    if (!characterId || !query) {
      return res.status(400).json({ 
        error: 'Missing required fields: characterId and query' 
      });
    }
    
    console.log(`[TSE API] Knowledge request for ${characterId}: "${query}"`);
    
    const response = await knowledgeEngine.generateKnowledgeResponse(
      characterId,
      query,
      context || {}
    );
    
    res.json({
      success: true,
      response: response
    });
    
  } catch (error) {
    console.error('[TSE API] Knowledge response error:', error);
    res.status(500).json({ 
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

router.get('/knowledge/profile/:characterId', async (req, res) => {
  try {
    const { characterId } = req.params;
    
    console.log(`[TSE API] Profile request for ${characterId}`);
    
    const CharacterEngine = (await import('../engines/CharacterEngine_TEST.js')).default;
    const characterEngine = new CharacterEngine(characterId);
    await characterEngine.loadCharacter();
    
    const learningProfile = await knowledgeEngine.analyzeTraitProfile(
      characterEngine.traits,
      characterEngine.metadata
    );
    
    await characterEngine.cleanup();
    
    res.json({
      success: true,
      characterId: characterId,
      profile: learningProfile
    });
    
  } catch (error) {
    console.error('[TSE API] Profile error:', error);
    res.status(500).json({ 
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});

export default router;
