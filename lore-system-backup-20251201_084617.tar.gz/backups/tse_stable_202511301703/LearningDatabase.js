import { ensureConcept } from "./helpers/ensureConcept.js";
import generateHexId from "../utils/hexIdGenerator.js";
import pool from "../db/pool.js";
import { embedText, cosineSimilarity } from "./helpers/semanticUtils.js";
import traitManager from "../traits/TraitManager.js";

export default class LearningDatabase {
  constructor(dbPool) {
    this.pool = dbPool;
  }

  async createCycle(acquired) {
    if (!acquired) throw new Error("createCycle: acquired payload missing");
    if (!acquired.characterId) throw new Error("createCycle: missing characterId");

    const characterId = acquired.characterId;
    const query = acquired.query || acquired.content;

    if (!query) throw new Error("createCycle: missing query/content");

    // Concept Sanitization
    let rawConcept = acquired.concept || query;
    let safeConcept = "unknown";
    try {
        safeConcept = typeof ensureConcept === 'function' ? ensureConcept(rawConcept) : rawConcept.substring(0, 50);
    } catch (e) {
        safeConcept = rawConcept.substring(0, 50);
    }

    // Embed
    let embedding = null;
    try {
        embedding = await embedText(query);
    } catch (e) {
        console.warn("[LearningDatabase] Embedding failed, continuing without vector:", e.message);
    }

    // Check Reuse
    if (embedding) {
        const reuse = await this.findSimilarKnowledge(characterId, embedding);
        if (reuse) {
          console.log(`[LearningDatabase] Reusing knowledge ${reuse.knowledge_id}`);
          return {
            status: "reused",
            knowledge_id: reuse.knowledge_id,
            content: reuse.content,
            similarity: reuse.score
          };
        }
    }

    const domainId = await this.detectDomain(query);
    const complexity = await this.computeComplexity(characterId, query);
    const knowledgeId = await generateHexId("knowledge_item_id");

    const insertSQL = `
      INSERT INTO knowledge_items
        (knowledge_id, content, semantic_embedding, domain_id, source_type,
        initial_character_id, initial_strength, complexity_score, concept)
      VALUES ($1, $2, $3, $4, 'tse_cycle', $5, 1, $6, $7)
      RETURNING *
    `;

    const result = await this.pool.query(insertSQL, [
      knowledgeId,
      query,
      embedding ? JSON.stringify(embedding) : null,
      domainId,
      characterId,
      complexity,
      safeConcept
    ]);

    return {
      status: "created",
      knowledge: result.rows[0],
      knowledge_id: result.rows[0].knowledge_id
    };
  }

  // --- FIXED SAVE METHOD ---
  async saveTaskAttempt({ attemptId, taskId, characterId, knowledgeId, attemptText, score, metadata }) {
      // FIX: Extract taskType from metadata to satisfy DB constraint
      const taskType = metadata?.taskType || 'unknown';

      const sql = `
        INSERT INTO tse_task_attempts
        (attempt_id, task_id, character_id, knowledge_id, task_type, attempt_text, score, metadata, created_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW())
        RETURNING *
      `;

      try {
          const result = await this.pool.query(sql, [
              attemptId,
              taskId,
              characterId,
              knowledgeId,
              taskType, // <--- Inserted here
              attemptText,
              score,
              JSON.stringify(metadata)
          ]);
          return result.rows[0];
      } catch (err) {
          console.error("[LearningDatabase] Failed to save task attempt:", err);
          return null;
      }
  }
  // -----------------------

  async reviewKnowledge(characterId, knowledgeId, grade) {
    const reviewId = await generateHexId("knowledge_item_id"); 

    const sql = `
      INSERT INTO knowledge_review_logs
        (log_id, character_id, knowledge_id, grade,
        previous_interval, new_interval, retrievability_at_review)
      VALUES ($1, $2, $3, $4, 1, 1, 1)
      RETURNING *
    `;

    const result = await this.pool.query(sql, [
      reviewId,
      characterId,
      knowledgeId,
      grade
    ]);

    return result.rows[0];
  }

  async findSimilarKnowledge(characterId, queryEmbedding) {
    const sql = `
      SELECT knowledge_id, content, semantic_embedding
      FROM knowledge_items
      WHERE initial_character_id = $1
      AND semantic_embedding IS NOT NULL
    `;
    const result = await this.pool.query(sql, [characterId]);
    if (result.rows.length === 0) return null;

    let best = null;

    for (const row of result.rows) {
      try {
        const emb = JSON.parse(row.semantic_embedding);
        const score = cosineSimilarity(queryEmbedding, emb);
        if (!best || score > best.score) {
          best = { score, knowledge_id: row.knowledge_id, content: row.content };
        }
      } catch {}
    }

    if (best && best.score >= 0.82) return best;
    return null;
  }

  async detectDomain(query) {
    try {
        const rows = await this.pool.query(`
          SELECT domain_id, domain_name
          FROM knowledge_domains
          WHERE is_active = TRUE
        `);

        if (rows.rows.length === 0) return "#000000";

        const text = query.toLowerCase();
        const keywords = {
          story_basics: ["protagonist", "story", "plot", "goal", "conflict"],
          conversational: ["say", "speak", "respond", "dialogue"],
          system_docs: ["api", "server", "code", "module", "nlg"]
        };

        let best = null;

        for (const row of rows.rows) {
          const name = row.domain_name.toLowerCase();
          let score = 0;
          if (keywords.story_basics.some(k => text.includes(k)) && name.includes("story")) score += 0.7;
          if (keywords.conversational.some(k => text.includes(k)) && name.includes("convers")) score += 0.7;
          if (keywords.system_docs.some(k => text.includes(k)) && name.includes("system")) score += 0.7;
          if (!best || score > best.score) best = { score, domain: row.domain_id };
        }

        if (best && best.score > 0.6) return best.domain;

        return rows.rows[0]?.domain_id || "#00012C";
    } catch (e) {
        return "#00012C";
    }
  }

  async computeComplexity(characterId, query) {
    try {
      const traits = await traitManager.getTraitVector(characterId);
      const inquisitive = traits["#00005A"] || 50;
      const overwhelmed = traits["#000012"] || 50;
      let complexity = 0.5 + (inquisitive - 50) * 0.005 - (overwhelmed - 50) * 0.003;
      return Math.max(0.1, Math.min(1.0, complexity));
    } catch {
      return 0.5;
    }
  }

  async getRecentScores(characterId, limit = 5) {
    try {
        const sql = `
          SELECT score
          FROM tse_task_attempts
          WHERE character_id = $1
          ORDER BY created_at DESC
          LIMIT $2
        `;
        const result = await this.pool.query(sql, [characterId, limit]);
        return result.rows.map(r => r.score).filter(s => s !== null);
    } catch (e) {
        return [];
    }
  }

  async saveSessionMemory({
    memoryId,
    characterId,
    knowledgeId,
    taskId,
    attemptId,
    score,
    difficulty,
    sessionSummary,
    metadata
  }) {
    const sql = `
      INSERT INTO character_session_memory
      (memory_id, character_id, knowledge_id, task_id, attempt_id, score, difficulty, session_summary, metadata)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
    `;
    await this.pool.query(sql, [
      memoryId,
      characterId,
      knowledgeId,
      taskId,
      attemptId,
      score,
      difficulty,
      sessionSummary,
      JSON.stringify(metadata)
    ]);
    return true;
  }

  async loadSessionMemory(characterId, limit = 10) {
    const sql = `
      SELECT *
      FROM character_session_memory
      WHERE character_id = $1
      ORDER BY created_at DESC
      LIMIT $2
    `;
    const result = await this.pool.query(sql, [characterId, limit]);
    return result.rows;
  }
}
