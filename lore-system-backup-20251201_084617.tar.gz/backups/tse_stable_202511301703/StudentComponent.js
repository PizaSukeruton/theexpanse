import traitManager from "../traits/TraitManager.js";
import generateHexId from "../utils/hexIdGenerator.js";
import pool from "../db/pool.js";

export default class StudentComponent {
  constructor() {
    this.pool = pool;
    // Fix: traitManager is already an instance, so we don't use 'new'
    this.traits = traitManager;
    this.nodeId = Math.floor(Math.random() * 256).toString(16).toUpperCase();
  }

  async initialize() {
    return true;
  }

  async learn(characterId, knowledgeId, task) {
    const attemptId = await generateHexId("tse_attempt_id");

    let attemptText = "";

    switch (task.taskType) {
      case "cause_effect_rewrite":
        attemptText = this._attemptCauseEffectRewrite(task.input);
        break;
      case "sentence_clarity_rewrite":
        attemptText = this._attemptSentenceClarityRewrite(task.input);
        break;
      case "summarize_core_point":
        attemptText = this._attemptSummarizeCorePoint(task.input);
        break;
      default:
        attemptText = "I do not understand this task yet.";
        break;
    }

    attemptText = await this._applyPersonalityErrors(characterId, attemptText);

    return {
      attemptId,
      taskId: task.taskId,
      characterId,
      knowledgeId,
      attemptText,
      studentNode: this.nodeId
    };
  }

  _attemptCauseEffectRewrite(text) {
    return text + " (cause-effect rewritten)";
  }

  _attemptSentenceClarityRewrite(text) {
    return text + " (clarity improved)";
  }

  _attemptSummarizeCorePoint(text) {
    return text + " (summary of core point)";
  }

  async _applyPersonalityErrors(characterId, text) {
    const traits = await this.traits.getTraitVector(characterId);
    let result = text;

    const impulsive = traits["#0000A1"] || 50;
    const forgetful = traits["#0000B2"] || 50;
    const detailOriented = traits["#0000C3"] || 50;
    const overconfident = traits["#0000D4"] || 50;

    if (impulsive > 70 && result.includes(".")) {
      const parts = result.split(".");
      if (parts.length > 1) parts.pop();
      result = parts.join(".") + ".";
    }

    if (forgetful > 65) {
      result = result.replace(/\b(because|so|therefore|as a result|which led to|which caused)\b/gi, "...");
    }

    if (detailOriented > 60) {
      result += " (note: attention to details included)";
    }

    if (overconfident > 75) {
      result = "I know this! " + result;
    }

    return result;
  }
}
