#!/bin/bash
cd /Users/pizasukeruton/Desktop/theexpanse/theexpansev005/backend
cp ~/Downloads/GPT_PHASE1_LESSONS_COMPLETE.json ./
ls -lah GPT_PHASE1_LESSONS_COMPLETE.json
echo "✓ JSON file copied successfully"
