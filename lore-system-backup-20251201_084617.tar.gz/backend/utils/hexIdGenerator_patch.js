// PATCH: insert into your main hexIdGenerator.js manually

// Add inside your ID_TYPE_RANGES map:

tse_review_log_id: {
    prefix: "#8003",
    min: 0xA0,
    max: 0xFF
},

// END PATCH
