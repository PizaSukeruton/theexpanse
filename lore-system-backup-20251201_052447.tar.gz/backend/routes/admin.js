import express from 'express';
import { authLimiter } from '../middleware/rateLimiter.js';
import { verifyAdminAuth } from '../middleware/auth.js';
import { validate } from '../utils/validator.js';import bcrypt from 'bcryptjs';
import pool from '../db/pool.js';
import { generateToken, verifyToken as verifyTokenJWT } from '../utils/jwtUtil.js';

import UserManager from '../auth/UserManager.js';
const router = express.Router();

router.post('/login', authLimiter, validate({ username: { required: true, type: 'username' }, password: { required: true, type: 'password' } }), async (req, res) => {
    const { username, password } = req.body;
  try {
    
    // Verify user credentials using UserManager
    const result = await UserManager.verifyUser(username, password);
    
    if (!result.success) {
      return res.status(401).json({ 
        success: false, 
        message: result.error 
      });
    }
    
    const user = result.user;
    
    // Check if user has admin role
    if (user.role !== 'admin' && (!user.access_level || user.access_level < 11)) {
      return res.status(403).json({ 
        success: false, 
        message: 'Admin access required' 
      });
    }
    
    // Generate JWT token
    const token = generateToken(user);
    
    res.json({
      success: true,
      token,
      user: {
        user_id: user.user_id || user.id,
        access_level: user.access_level,
        username: user.username,
        role: user.role,
        email: user.email
      }
    });
    
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Authentication failed' 
    });
  }
});
router.get('/verify', verifyAdminAuth, async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ 
        success: false, 
        message: 'No token provided' 
      });
    }
    
    const decoded = verifyAdminAuthJWT(token);
    res.json({ success: true, user: decoded });
    
  } catch (error) {
    res.status(401).json({ 
      success: false, 
      message: error.message 
    });
  }
});

import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { dirname } from "path";
import sharp from 'sharp';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const storage = multer.memoryStorage();

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

async function applyCRTFilter(buffer) {
  try {
    const processed = await sharp(buffer)
      .modulate({
        brightness: 1.1,
        saturation: 0.7
      })
      .tint({ r: 0, g: 30, b: 0 })
      .gamma(1.4)
      .blur(0.3)
      .sharpen({ sigma: 0.5 })
      .toBuffer();
    
    return processed;
  } catch (error) {
    console.error('Error applying CRT filter:', error);
    return buffer;
  }
}

router.post("/media", verifyAdminAuth, upload.single("image"), async (req, res) => {
  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');
    
    const hexResult = await client.query(
      'SELECT get_next_hex_id($1) as hex_id', 
      ['multimedia_asset']
    );
    const hexId = hexResult.rows[0].hex_id;
    
    console.log(`Sequential HEX ID: ${hexId}`);
    
    let processedBuffer = req.file.buffer;
    if (req.body.applyCRT === 'true') {
      console.log('Applying CRT filter...');
      processedBuffer = await applyCRTFilter(req.file.buffer);
    }
    
    const ext = path.extname(req.file.originalname);
    const hexClean = hexId.substring(1);
    const filename = `${hexClean}${ext}`;
    
    const uploadPath = path.join(__dirname, "../public/gallery");
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }
    
    const filepath = path.join(uploadPath, filename);
    
    if (fs.existsSync(filepath)) {
      throw new Error(`File with hex ID ${hexId} already exists!`);
    }
    
    fs.writeFileSync(filepath, processedBuffer);
    
    const relationships = req.body.relationships ? JSON.parse(req.body.relationships) : [];
    
    const result = await client.query(
      `INSERT INTO multimedia_assets (
        asset_id, 
        asset_type, 
        url,
        description,
        original_filename,
        file_size,
        mime_type,
        tags
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [
        hexId,
        'image',
        `/gallery/${filename}`,
        req.body.title || 'Uploaded image',
        req.file.originalname,
        processedBuffer.length,
        req.file.mimetype,
        req.body.tags ? req.body.tags.split(',').map(t => t.trim()) : []
      ]
    );
    
    for (const rel of relationships) {
      await client.query(
        `INSERT INTO hex_relationships (source_hex, target_hex, relationship_type, metadata)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT DO NOTHING`,
        [hexId, rel.target_hex, rel.relationship_type || 'depicts', rel.metadata || {}]
      );
    }
    
    await client.query('COMMIT');
    
    res.json({
      success: true,
      hex_id: hexId,
      filepath: `/gallery/${filename}`,
      asset: result.rows[0],
      message: `Media uploaded: ${hexId} (${filename})`
    });
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Upload error:', error);
    res.status(400).json({ error: error.message });
  } finally {
    client.release();
  }
});

router.get("/media", verifyAdminAuth, async (req, res) => {
  try {
    const query = `
      SELECT 
        ma.asset_id,
        ma.asset_type,
        ma.url,
        ma.description,
        ma.original_filename,
        ma.tags,
        ma.created_at,
        COALESCE(
          json_agg(
            json_build_object(
              'hex_id', he.hex_id,
              'name', he.name,
              'entity_type', he.entity_type,
              'relationship', hr.relationship_type
            )
          ) FILTER (WHERE he.hex_id IS NOT NULL),
          '[]'::json
        ) as relationships
      FROM multimedia_assets ma
      LEFT JOIN hex_relationships hr ON hr.source_hex = ma.asset_id
      LEFT JOIN hex_entities he ON he.hex_id = hr.target_hex
      WHERE ma.asset_type = 'image'
      GROUP BY ma.asset_id, ma.asset_type, ma.url, ma.description, 
               ma.original_filename, ma.tags, ma.created_at
      ORDER BY ma.created_at DESC
    `;
    
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/entities", verifyAdminAuth, async (req, res) => {
  try {
    const { entity_type } = req.query;
    
    let query = 'SELECT * FROM hex_entities';
    const params = [];
    
    if (entity_type) {
      query += ' WHERE entity_type = $1';
      params.push(entity_type);
    }
    
    query += ' ORDER BY hex_id LIMIT 100';
    
    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/hex/next/:entityType", verifyAdminAuth, async (req, res) => {
  try {
    const entityTypeMap = {
      'multimedia': 'multimedia_asset',
      'character': 'character',
      'location': 'location',
      'story_arc': 'story_arc',
      'knowledge': 'knowledge_entry'
    };
    
    const dbEntityType = entityTypeMap[req.params.entityType] || req.params.entityType;
    
    const result = await pool.query(
      'SELECT get_next_hex_id($1) as hex_id',
      [dbEntityType]
    );
    
    res.json({
      success: true,
      entity_type: dbEntityType,
      hex_id: result.rows[0].hex_id
    });
    
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post("/relationships", verifyAdminAuth, async (req, res) => {
  try {
    const { source_hex, target_hex, relationship_type, metadata } = req.body;
    
    await pool.query(
      `INSERT INTO hex_relationships (source_hex, target_hex, relationship_type, metadata)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (source_hex, target_hex, relationship_type) 
       DO UPDATE SET metadata = $4`,
      [source_hex, target_hex, relationship_type, metadata || {}]
    );
    
    res.json({
      success: true,
      message: `Relationship created: ${source_hex} ${relationship_type} ${target_hex}`
    });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get("/relationships/:hexId", verifyAdminAuth, async (req, res) => {
  try {
    const hexId = '#' + req.params.hexId.replace('#', '');
    
    const result = await pool.query(
      'SELECT * FROM get_entity_relationships($1)',
      [hexId]
    );
    
    res.json({
      success: true,
      hex_id: hexId,
      relationships: result.rows
    });
    
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/stats", verifyAdminAuth, async (req, res) => {
  try {
    const stats = await pool.query(`
      SELECT 
        (SELECT COUNT(*) FROM hex_relationships) as total_relationships,
        (SELECT COUNT(*) FROM multimedia_assets WHERE asset_type = 'image') as total_images,
        (SELECT COUNT(*) FROM multimedia_assets WHERE asset_type = 'video') as total_videos,
        (SELECT COUNT(*) FROM character_profiles) as total_characters,
        (SELECT COUNT(*) FROM story_arcs) as total_story_arcs,
        (SELECT COUNT(*) FROM locations) as total_locations,
        (SELECT COUNT(*) FROM knowledge_items) as total_knowledge
    `);
    
    const hexCounters = await pool.query('SELECT * FROM hex_counters ORDER BY entity_type');
    
    res.json({
      success: true,
      stats: stats.rows[0],
      hex_counters: hexCounters.rows
    });
    
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;

// Knowledge Entity Management Routes
router.get('/knowledge-entities', verifyAdminAuth, async (req, res) => {
  try {
    const query = `
      SELECT 
        cp.character_id,
        cp.character_name,
        cp.description,
        COUNT(ki.knowledge_id) as knowledge_count
      FROM character_profiles cp
      LEFT JOIN knowledge_items ki ON ki.initial_character_id = cp.character_id
      WHERE cp.category = 'Knowledge Entity'
      GROUP BY cp.character_id, cp.character_name, cp.description
      ORDER BY cp.character_name
    `;
    
    const result = await pool.query(query);
    
    res.json({
      success: true,
      entities: result.rows
    });
  } catch (error) {
    console.error('Error fetching knowledge entities:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Add knowledge item for an entity
router.post('/knowledge-item', verifyAdminAuth, async (req, res) => {
  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');
    
    const { entity_id, entity_name, statement, difficulty } = req.body;
    
    // Generate knowledge ID
    const hexResult = await client.query(
      "SELECT '#' || LPAD(TO_HEX(COALESCE(MAX(CAST(SUBSTRING(knowledge_id FROM 2) AS INT)), 11468800) + 1), 6, '0') AS hex_id FROM knowledge_items WHERE knowledge_id LIKE '#AF%'"
    );
    const knowledgeId = hexResult.rows[0].hex_id;
    
    // Create JSON content
    const content = {
      type: 'fact',
      subject: entity_name,
      statement: statement,
      entity_id: entity_id
    };
    
    // Insert knowledge item
    await client.query(
      `INSERT INTO knowledge_items (
        knowledge_id,
        content,
        domain_id,
        source_type,
        initial_character_id,
        complexity_score,
        concept
      ) VALUES ($1, $2, $3, $4, $5, $6, $7)`,
      [
        knowledgeId,
        JSON.stringify(content),
        '#AE0001', // General knowledge domain
        'admin_entry',
        entity_id,
        (difficulty || 50) / 100.0,
        entity_name.toLowerCase().replace(/\s+/g, '_')
      ]
    );
    
    await client.query('COMMIT');
    
    res.json({
      success: true,
      knowledge_id: knowledgeId,
      message: 'Knowledge item added successfully'
    });
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error adding knowledge item:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  } finally {
    client.release();
  }
});


// Create standalone Knowledge Entity
router.post('/knowledge-entity/create', verifyAdminAuth, async (req, res) => {
  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');
    
    const { entity_name, description, password } = req.body;
    
    // Validate required fields
    if (!entity_name || !password) {
      throw new Error('Entity name and password are required');
    }
    
    // Generate hex ID for the knowledge entity
    const generateHexId = (await import('../utils/hexIdGenerator.js')).default;
    const entityId = await generateHexId('character_id');
    
    // Create the Knowledge Entity
    const entityResult = await client.query(
      `INSERT INTO character_profiles (
        character_id,
        character_name,
        category,
        description,
        is_b_roll_autonomous,
        created_at
      ) VALUES ($1, $2, $3, $4, NULL, CURRENT_TIMESTAMP)
      RETURNING character_id, character_name`,
      [entityId, entity_name, 'Knowledge Entity', description || '']
    );
    
    await client.query('COMMIT');
    
    res.json({
      success: true,
      entity: entityResult.rows[0],
      message: `Knowledge Entity ${entityId} created successfully`
    });
    
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error creating knowledge entity:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  } finally {
    client.release();
  }
});


// Get single entity with details - FIXED VERSION
router.get('/knowledge-entity/:entityId', verifyAdminAuth, async (req, res) => {
  const { entityId } = req.params;
  
  try {
    // Get entity details
    const entityResult = await pool.query(
      'SELECT * FROM character_profiles WHERE character_id = $1 AND category = $2',
      [entityId, 'Knowledge Entity']
    );
    
    if (entityResult.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        error: 'Knowledge Entity not found' 
      });
    }
    
    const entity = entityResult.rows[0];
    
    // Get knowledge items
    const knowledgeResult = await pool.query(
      'SELECT * FROM knowledge_items WHERE initial_character_id = $1 ORDER BY acquisition_timestamp DESC',
      [entityId]
    );
    
    // Get relationships using hex_relationships
    const relationshipsResult = await pool.query(
      'SELECT hr.*, cp1.character_name as source_name, cp2.character_name as target_name ' +
      'FROM hex_relationships hr ' +
      'LEFT JOIN character_profiles cp1 ON hr.source_hex = cp1.character_id ' +
      'LEFT JOIN character_profiles cp2 ON hr.target_hex = cp2.character_id ' +
      'WHERE hr.source_hex = $1 OR hr.target_hex = $1 ' +
      'ORDER BY hr.created_at DESC',
      [entityId]
    );
    
    res.json({
      success: true,
      entity,
      knowledge_items: knowledgeResult.rows,
      relationships: relationshipsResult.rows
    });
    
  } catch (error) {
    console.error('Error fetching entity details:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});
// Update Knowledge Entity
router.put('/knowledge-entity/:entityId', verifyAdminAuth, async (req, res) => {
  const { entityId } = req.params;
  const { character_name, description } = req.body;
  
  try {
    const result = await pool.query(
      `UPDATE character_profiles 
       SET character_name = COALESCE($2, character_name),
           description = COALESCE($3, description)
       WHERE character_id = $1 AND category = 'Knowledge Entity'
       RETURNING *`,
      [entityId, character_name, description]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        error: 'Knowledge Entity not found' 
      });
    }
    
    res.json({
      success: true,
      entity: result.rows[0],
      message: 'Knowledge Entity updated successfully'
    });
    
  } catch (error) {
    console.error('Error updating entity:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Create entity relationship
router.post('/entity-relationship', verifyAdminAuth, async (req, res) => {
  const { source_hex, target_hex, relationship_type, metadata } = req.body;
  
  try {
    // Validate hex IDs
    const { isValidHexId } = await import('../utils/hexIdGenerator.js');
    if (!isValidHexId(source_hex) || !isValidHexId(target_hex)) {
      throw new Error('Invalid hex ID format');
    }
    
    const result = await pool.query(
      `INSERT INTO hex_relationships (
        source_hex, 
        target_hex, 
        relationship_type, 
        metadata,
        created_by
      ) VALUES ($1, $2, $3, $4, $5)
      ON CONFLICT (source_hex, target_hex, relationship_type) 
      DO UPDATE SET metadata = $4
      RETURNING *`,
      [source_hex, target_hex, relationship_type, metadata || {}, req.user?.user_id || null]
    );
    
    res.json({
      success: true,
      relationship: result.rows[0],
      message: `Relationship created: ${source_hex} ${relationship_type} ${target_hex}`
    });
    
  } catch (error) {
    console.error('Error creating relationship:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Delete entity relationship
router.delete('/entity-relationship/:relationshipId', verifyAdminAuth, async (req, res) => {
  const { relationshipId } = req.params;
  
  try {
    const result = await pool.query(
      'DELETE FROM hex_relationships WHERE relationship_id = $1 RETURNING *',
      [relationshipId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        error: 'Relationship not found' 
      });
    }
    
    res.json({
      success: true,
      message: 'Relationship deleted successfully'
    });
    
  } catch (error) {
    console.error('Error deleting relationship:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

// Get available relationship types
router.get('/relationship-types', verifyAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT * FROM relationship_types ORDER BY type_name'
    );
    
    res.json({
      success: true,
      types: result.rows
    });
    
  } catch (error) {
    console.error('Error fetching relationship types:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});
// System Settings Routes
router.get('/settings/:setting_key', verifyAdminAuth, async (req, res) => {
  try {
    const { setting_key } = req.params;
    
    const result = await pool.query(
      'SELECT setting_value FROM system_settings WHERE setting_key = $1',
      [setting_key]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        error: 'Setting not found' 
      });
    }
    
    res.json({
      success: true,
      key: setting_key,
      value: result.rows[0].setting_value
    });
  } catch (error) {
    console.error('Error fetching setting:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

router.post('/settings/:setting_key', verifyAdminAuth, async (req, res) => {
  try {
    const { setting_key } = req.params;
    const { value } = req.body;
    
    await pool.query(
      `INSERT INTO system_settings (setting_key, setting_value, updated_by, updated_at)
       VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
       ON CONFLICT (setting_key) 
       DO UPDATE SET setting_value = $2, updated_by = $3, updated_at = CURRENT_TIMESTAMP`,
      [setting_key, value, req.user?.user_id || '#D00001']
    );
    
    res.json({
      success: true,
      message: 'Setting updated successfully'
    });
  } catch (error) {
    console.error('Error updating setting:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

router.get('/pending-users', verifyAdminAuth, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT user_id, username, email, created_at, email_verified, approval_status
       FROM users
       WHERE approval_status = 'pending'
       ORDER BY acquisition_timestamp DESC`
    );
    
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching pending users:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

router.post('/approve-user/:user_id', verifyAdminAuth, async (req, res) => {
  try {
    const { user_id } = req.params;
    
    const result = await pool.query(
      `UPDATE users 
       SET approval_status = 'approved', approved_at = CURRENT_TIMESTAMP
       WHERE user_id = $1
       RETURNING username, email`,
      [user_id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        error: 'User not found' 
      });
    }
    
    const user = result.rows[0];
    
//     const { sendApprovalEmail } = await import('../backend/utils/emailSender.js');
//     await sendApprovalEmail(user.email, user.username);
    
    res.json({
      success: true,
      message: 'User approved successfully'
    });
  } catch (error) {
    console.error('Error approving user:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});

router.post('/reject-user/:user_id', verifyAdminAuth, async (req, res) => {
  try {
    const { user_id } = req.params;
    
    const result = await pool.query(
      `UPDATE users 
       SET approval_status = 'rejected'
       WHERE user_id = $1
       RETURNING username, email`,
      [user_id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        error: 'User not found' 
      });
    }
    
    const user = result.rows[0];
    
    const { sendRejectionEmail } = await import('../backend/utils/emailSender.js');
    await sendRejectionEmail(user.email, user.username);
    
    res.json({
      success: true,
      message: 'User rejected successfully'
    });
  } catch (error) {
    console.error('Error rejecting user:', error);
    res.status(500).json({ 
      success: false, 
      error: error.message 
    });
  }
});
