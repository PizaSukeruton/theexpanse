import pool from "../db/pool.js";
import generateHexId from "../utils/hexIdGenerator.js";

class LoreAnswerEvaluator {
  static normalize(text) {
    if (!text) return "";
    return text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  static extractKeywords(canonicalFacts = {}, properties = {}) {
    const chunks = [];

    if (canonicalFacts && typeof canonicalFacts === "object") {
      if (canonicalFacts.core_fact) chunks.push(canonicalFacts.core_fact);
      if (canonicalFacts.category) chunks.push(canonicalFacts.category);
      for (const [key, value] of Object.entries(canonicalFacts)) {
        if (typeof value === "string" && key !== "core_fact" && key !== "category") {
          chunks.push(value);
        }
      }
    }

    if (properties && typeof properties === "object") {
      for (const value of Object.values(properties)) {
        if (typeof value === "string") chunks.push(value);
      }
    }

    const keywords = new Set();

    for (const chunk of chunks) {
      const norm = this.normalize(chunk);
      if (!norm) continue;

      for (const token of norm.split(" ")) {
        if (token.length >= 4) {
          keywords.add(token);
        }
      }
    }

    return Array.from(keywords);
  }

  static scoreAnswer({ canonicalFacts, properties, userAnswer }) {
    const normalizedAnswer = this.normalize(userAnswer);
    const answerTokens = new Set(normalizedAnswer.split(" ").filter(Boolean));

    const keywords = this.extractKeywords(canonicalFacts, properties);

    let matched = [];
    let missed = [];

    for (const kw of keywords) {
      if (answerTokens.has(kw)) {
        matched.push(kw);
      } else {
        missed.push(kw);
      }
    }

    const total = keywords.length || 1;
    const matchRatio = matched.length / total;

    let score = 0;
    if (matchRatio >= 0.80) score = 5;
    else if (matchRatio >= 0.60) score = 4;
    else if (matchRatio >= 0.40) score = 3;
    else if (matchRatio >= 0.20) score = 2;
    else if (matchRatio > 0) score = 1;
    else score = 0;

    let feedback;
    if (score >= 4) {
      feedback = "Strong answer. You captured most of the key details.";
    } else if (score === 3) {
      feedback = "Partially correct. You have some key details but missed others.";
    } else if (score === 2) {
      feedback = "Limited correctness. You mentioned a few relevant ideas but missed core facts.";
    } else if (score === 1) {
      feedback = "Very limited match. The answer barely aligns with the canonical facts.";
    } else {
      feedback = "No clear match to the canonical facts.";
    }

    return {
      score,
      normalizedAnswer,
      keywords,
      matchedKeywords: matched,
      missedKeywords: missed,
      matchRatio
    };
  }

  static async evaluateAndStore({ task, characterId, answer }) {
    if (!task || !task.taskId) {
      throw new Error("Task with taskId is required");
    }
    if (!characterId) {
      throw new Error("characterId is required for evaluation");
    }
    if (!answer || !answer.trim()) {
      throw new Error("Answer text is required");
    }

    const knowledgeId = task.knowledgeId || null;

    let canonicalFacts = null;
    let properties = null;

    if (knowledgeId) {
      const loreRes = await pool.query(
        `
        SELECT canonical_facts, properties
        FROM lore_knowledge_graph
        WHERE knowledge_id = $1
        `,
        [knowledgeId]
      );

      if (loreRes.rows.length > 0) {
        canonicalFacts = loreRes.rows[0].canonical_facts || null;
        properties = loreRes.rows[0].properties || null;
      }
    }

    const scoring = this.scoreAnswer({
      canonicalFacts,
      properties,
      userAnswer: answer
    });

    const responseId = await generateHexId("tse_evaluation_record_id");

    const evaluatorDetails = {
      knowledgeId,
      scoring,
      canonicalFacts,
      properties
    };

    await pool.query(
      `
      INSERT INTO lore_task_responses (
        response_id,
        task_id,
        character_id,
        knowledge_id,
        user_answer,
        normalized_answer,
        score,
        feedback,
        evaluator_details
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
      `,
      [
        responseId,
        task.taskId,
        characterId,
        knowledgeId,
        answer,
        scoring.normalizedAnswer,
        scoring.score,
        scoring.score + " / 5 - " + scoring.matchRatio.toFixed(2) + " match ratio",
        evaluatorDetails
      ]
    );

    return {
      responseId,
      taskId: task.taskId,
      characterId,
      knowledgeId,
      score: scoring.score,
      feedback: scoring.score + " / 5 - " + scoring.matchRatio.toFixed(2) + " match ratio",
      details: scoring
    };
  }
}

export default LoreAnswerEvaluator;
