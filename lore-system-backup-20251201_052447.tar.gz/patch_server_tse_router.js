import tseRouter from './backend/api/tseRouter.js';
app.use('/api/tse', tseRouter);
