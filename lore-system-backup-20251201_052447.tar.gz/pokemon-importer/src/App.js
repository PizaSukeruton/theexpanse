import AdminQuestionImport from './components/AdminQuestionImport';

function App() {
  return (
    <div>
      <AdminQuestionImport />
    </div>
  );
}

export default App;
